/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        cyan: {
          DEFAULT: "#00f0ff",
          dim: "rgba(0,240,255,0.15)",
          glow: "rgba(0,240,255,0.6)",
        },
        bg: {
          deep: "#0e0105",
          panel: "rgba(20, 2, 8, 0.85)",
        },
        ink: {
          DEFAULT: "#ffffff",
          dim: "rgba(255,235,240,0.75)",
        },
        line: {
          DEFAULT: "rgba(0,240,255,0.18)",
          bright: "rgba(0,240,255,0.45)",
        },
        status: {
          new: "#00f0ff",
          progress: "#ffb800",
          waiting: "#a78bfa",
          done: "#33ff99",
          archived: "#6b7280",
          overdue: "#ff3b5c",
        },
      },
      fontFamily: {
        display: ["Orbitron", "sans-serif"],
        body: ["Rajdhani", "sans-serif"],
      },
      borderRadius: {
        nv: "8px",
      },
      boxShadow: {
        glow: "0 0 24px rgba(0,240,255,0.15), inset 0 0 20px rgba(0,240,255,0.04)",
      },
    },
  },
  plugins: [],
};
