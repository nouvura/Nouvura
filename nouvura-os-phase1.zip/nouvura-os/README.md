# NOUVURA OS — Phase 1 (Foundation)

Offline business operating system for NOUVURA, built on the existing
cyan/red cyberpunk identity. This is **Phase 1 of a phased build** — see
"Roadmap" below for what's left.

## What's in this phase

- Full Tauri 2 + React + TypeScript + Tailwind scaffold, enterprise folder
  structure (`components / layouts / pages / store / i18n / lib / types`
  on the frontend, `db / commands / models` on the Rust side).
- SQLite database (via `rusqlite`, bundled — no system SQLite install
  needed) with the core schema: clients, projects, quotes, invoices,
  payments, activity_log, settings. Automatic folder structure created
  under the OS app-data directory on first launch.
- Database integrity check + timestamped backup/restore commands.
- French / English / Arabic i18n, French default on first launch, full
  Arabic RTL layout switching, language persisted locally.
- App shell: collapsible sidebar with all 10 module entries, topbar with
  search and language switcher, matching your existing glass-panel /
  corner-accent / cyan-glow visual language.
- **Dashboard** — fully wired to real SQLite stats (clients, active/
  delayed/completed projects, revenue, pending invoices) with a revenue
  chart and recent-activity feed.
- **Clients (CRM)** — fully wired end-to-end: list, create, edit, delete,
  all persisted to SQLite. This is the reference pattern every other
  module (Projects, Quotes, Invoices...) will follow in the next phases.
- Other 8 modules exist as routed placeholder pages so navigation and
  layout are already complete; they get real functionality in Phases 2–4.

## Prerequisites (on your Windows machine — not in this sandbox)

This project was written and structured here, but **cannot be installed,
compiled, or run inside this chat's environment** — there's no network
access to fetch npm/cargo packages and no Rust/Windows build toolchain
available here. You'll build it locally:

1. [Node.js](https://nodejs.org) 18+
2. [Rust](https://www.rust-lang.org/tools/install) (stable toolchain)
3. Tauri's Windows prerequisites: **Microsoft C++ Build Tools** (Desktop
   development with C++ workload) and **WebView2** (preinstalled on
   modern Windows, otherwise [download here](https://developer.microsoft.com/microsoft-edge/webview2/))
4. Full guide if anything's missing: https://v2.tauri.app/start/prerequisites/

## Setup

```bash
npm install
npm run tauri icon path/to/your/nouvura-logo.png   # generates all icon sizes
npm run tauri dev                                  # launches the desktop app
```

To build the installable Windows app:

```bash
npm run tauri build
```

This produces an NSIS installer under `src-tauri/target/release/bundle/nsis/`.

You can also iterate on the UI alone in a regular browser tab with
`npm run dev` (no Rust/SQLite — it auto-falls-back to mock data, see
`src/lib/db.ts`), which is much faster for visual tweaks before wiring a
new module to the database.

## Important: fonts must be self-hosted for true offline use

`index.html` currently loads Orbitron/Rajdhani from Google Fonts'
CDN, copied from your original site. Since the offline-first requirement
is mandatory, download both font families' `.woff2` files, place them in
`src/assets/fonts/`, and replace the `<link>` tag with local `@font-face`
rules in `src/styles/globals.css`. Otherwise the app will render with
fallback fonts on a machine with no internet on first launch.

## Where your data lives

Everything is local, under the OS-standard app-data directory
(`%APPDATA%\NouvuraOS` on Windows):

```
NouvuraOS/
  Database/nouvura.db
  Backups/
  Clients/
  Projects/
  Invoices/
  Archive/
```

No network calls exist anywhere in `src/lib/db.ts` or the Rust backend —
everything goes through Tauri's local `invoke` bridge to SQLite.

## Roadmap

- **Phase 2** — Projects module (statuses, priorities, progress, deadlines,
  per-project folder auto-creation under `Projects/<code>/{Brief,Source,
  Working,Final,Invoice,Archive}`) + File Management (quick-open folders).
- **Phase 3** — Quotations + Invoices with PDF generation and printing,
  payment tracking, auto-numbering.
- **Phase 4** — Calendar, Notification Center, Reports & Analytics (PDF/
  Excel export), Archive system, and a full Settings page (theme, backup
  scheduling, data paths).

Each phase follows the exact pattern already proven in `Clients.tsx` +
`commands.rs`: Rust command → `lib/db.ts` → typed React page. Tell me
which phase to build next whenever you're ready.
