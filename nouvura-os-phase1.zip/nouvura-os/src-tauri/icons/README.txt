Place your app icons here (32x32.png, 128x128.png, 128x128@2x.png, icon.icns, icon.ico). Use 'npm run tauri icon path/to/logo.png' to auto-generate all sizes from your NOUVURA logo.
