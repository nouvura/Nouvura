use rusqlite::Connection;
use std::fs;
use std::path::PathBuf;
use std::sync::Mutex;
use chrono::Local;
use anyhow::Result;

pub struct DbState(pub Mutex<Connection>);

/// All NOUVURA OS data lives under the OS app-data directory, never on a
/// network share or cloud-synced path, in line with the offline-first
/// requirement. Layout:
///   <app_data>/Database/nouvura.db
///   <app_data>/Backups/
///   <app_data>/Clients/<client>/...
///   <app_data>/Projects/<project_code>/{Brief,Source,Working,Final,Invoice,Archive}/
///   <app_data>/Invoices/
///   <app_data>/Archive/
pub fn app_data_dir() -> PathBuf {
    let base = dirs::data_dir().expect("could not resolve OS data directory");
    base.join("NouvuraOS")
}

pub fn ensure_folder_structure() -> Result<()> {
    let root = app_data_dir();
    for sub in ["Database", "Backups", "Clients", "Projects", "Invoices", "Archive"] {
        fs::create_dir_all(root.join(sub))?;
    }
    Ok(())
}

pub fn db_path() -> PathBuf {
    app_data_dir().join("Database").join("nouvura.db")
}

pub fn init_connection() -> Result<Connection> {
    ensure_folder_structure()?;
    let conn = Connection::open(db_path())?;
    conn.execute_batch("PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL;")?;
    run_migrations(&conn)?;
    Ok(conn)
}

fn run_migrations(conn: &Connection) -> Result<()> {
    conn.execute_batch(
        r#"
        CREATE TABLE IF NOT EXISTS clients (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            company TEXT,
            phone TEXT,
            email TEXT,
            address TEXT,
            notes TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS projects (
            id TEXT PRIMARY KEY,
            code TEXT NOT NULL UNIQUE,
            client_id TEXT NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
            title TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'new',
            priority TEXT NOT NULL DEFAULT 'medium',
            deadline TEXT,
            budget REAL,
            progress INTEGER NOT NULL DEFAULT 0,
            notes TEXT,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS quotes (
            id TEXT PRIMARY KEY,
            number TEXT NOT NULL UNIQUE,
            client_id TEXT NOT NULL REFERENCES clients(id),
            project_id TEXT REFERENCES projects(id),
            items_json TEXT NOT NULL,
            total REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'draft',
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS invoices (
            id TEXT PRIMARY KEY,
            number TEXT NOT NULL UNIQUE,
            client_id TEXT NOT NULL REFERENCES clients(id),
            project_id TEXT REFERENCES projects(id),
            items_json TEXT NOT NULL,
            total REAL NOT NULL,
            paid_amount REAL NOT NULL DEFAULT 0,
            status TEXT NOT NULL DEFAULT 'unpaid',
            due_date TEXT,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS payments (
            id TEXT PRIMARY KEY,
            invoice_id TEXT NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
            amount REAL NOT NULL,
            method TEXT,
            paid_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS activity_log (
            id TEXT PRIMARY KEY,
            kind TEXT NOT NULL,
            message TEXT NOT NULL,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_projects_client ON projects(client_id);
        CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status);
        CREATE INDEX IF NOT EXISTS idx_invoices_client ON invoices(client_id);
        "#,
    )?;

    // Seed default settings on first run only
    conn.execute(
        "INSERT OR IGNORE INTO settings (key, value) VALUES ('language', 'fr')",
        [],
    )?;
    conn.execute(
        "INSERT OR IGNORE INTO settings (key, value) VALUES ('theme', 'dark')",
        [],
    )?;

    Ok(())
}

/// Copies the live database file to Backups/ with a timestamped name and
/// runs SQLite's integrity_check before/after to guard against corruption.
pub fn backup_database() -> Result<PathBuf> {
    let conn = Connection::open(db_path())?;
    let ok: String = conn.query_row("PRAGMA integrity_check", [], |r| r.get(0))?;
    if ok != "ok" {
        anyhow::bail!("Database integrity check failed before backup: {ok}");
    }
    drop(conn);

    let stamp = Local::now().format("%Y-%m-%d_%H-%M-%S");
    let dest = app_data_dir().join("Backups").join(format!("nouvura_backup_{stamp}.db"));
    fs::copy(db_path(), &dest)?;
    Ok(dest)
}

pub fn restore_database(backup_path: PathBuf) -> Result<()> {
    let conn = Connection::open(&backup_path)?;
    let ok: String = conn.query_row("PRAGMA integrity_check", [], |r| r.get(0))?;
    if ok != "ok" {
        anyhow::bail!("Selected backup failed integrity check: {ok}");
    }
    drop(conn);
    fs::copy(&backup_path, db_path())?;
    Ok(())
}
