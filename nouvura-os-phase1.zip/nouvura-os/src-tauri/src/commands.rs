use crate::db::DbState;
use crate::models::*;
use chrono::Local;
use rusqlite::params;
use tauri::State;
use uuid::Uuid;

fn now() -> String {
    Local::now().to_rfc3339()
}

fn log_activity(conn: &rusqlite::Connection, kind: &str, message: &str) {
    let _ = conn.execute(
        "INSERT INTO activity_log (id, kind, message, created_at) VALUES (?1, ?2, ?3, ?4)",
        params![Uuid::new_v4().to_string(), kind, message, now()],
    );
}

// ───────────────────────── Clients ─────────────────────────

#[tauri::command]
pub fn list_clients(state: State<DbState>) -> Result<Vec<Client>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let mut stmt = conn
        .prepare("SELECT id, name, company, phone, email, address, notes, created_at, updated_at FROM clients ORDER BY created_at DESC")
        .map_err(|e| e.to_string())?;
    let rows = stmt
        .query_map([], |r| {
            Ok(Client {
                id: r.get(0)?,
                name: r.get(1)?,
                company: r.get(2)?,
                phone: r.get(3)?,
                email: r.get(4)?,
                address: r.get(5)?,
                notes: r.get(6)?,
                created_at: r.get(7)?,
                updated_at: r.get(8)?,
            })
        })
        .map_err(|e| e.to_string())?;
    rows.collect::<Result<Vec<_>, _>>().map_err(|e| e.to_string())
}

#[tauri::command]
pub fn create_client(state: State<DbState>, payload: NewClient) -> Result<Client, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    let id = Uuid::new_v4().to_string();
    let ts = now();
    conn.execute(
        "INSERT INTO clients (id, name, company, phone, email, address, notes, created_at, updated_at)
         VALUES (?1, ?2, ?3, ?4, ?5, ?6, ?7, ?8, ?8)",
        params![id, payload.name, payload.company, payload.phone, payload.email, payload.address, payload.notes, ts],
    )
    .map_err(|e| e.to_string())?;
    log_activity(&conn, "client_created", &format!("Nouveau client : {}", payload.name));
    Ok(Client {
        id, name: payload.name, company: payload.company, phone: payload.phone,
        email: payload.email, address: payload.address, notes: payload.notes,
        created_at: ts.clone(), updated_at: ts,
    })
}

#[tauri::command]
pub fn update_client(state: State<DbState>, id: String, payload: NewClient) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "UPDATE clients SET name=?1, company=?2, phone=?3, email=?4, address=?5, notes=?6, updated_at=?7 WHERE id=?8",
        params![payload.name, payload.company, payload.phone, payload.email, payload.address, payload.notes, now(), id],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

#[tauri::command]
pub fn delete_client(state: State<DbState>, id: String) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.execute("DELETE FROM clients WHERE id=?1", params![id])
        .map_err(|e| e.to_string())?;
    Ok(())
}

// ───────────────────────── Dashboard ─────────────────────────

#[tauri::command]
pub fn get_dashboard_stats(state: State<DbState>) -> Result<DashboardStats, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;

    let total_clients: i64 = conn
        .query_row("SELECT COUNT(*) FROM clients", [], |r| r.get(0))
        .map_err(|e| e.to_string())?;
    let total_projects: i64 = conn
        .query_row("SELECT COUNT(*) FROM projects", [], |r| r.get(0))
        .map_err(|e| e.to_string())?;
    let active_projects: i64 = conn
        .query_row(
            "SELECT COUNT(*) FROM projects WHERE status IN ('new','in_progress','waiting_client')",
            [], |r| r.get(0),
        )
        .map_err(|e| e.to_string())?;
    let completed_projects: i64 = conn
        .query_row("SELECT COUNT(*) FROM projects WHERE status='completed'", [], |r| r.get(0))
        .map_err(|e| e.to_string())?;
    let delayed_projects: i64 = conn
        .query_row(
            "SELECT COUNT(*) FROM projects WHERE deadline IS NOT NULL AND deadline < ?1 AND status NOT IN ('completed','archived')",
            params![Local::now().format("%Y-%m-%d").to_string()],
            |r| r.get(0),
        )
        .map_err(|e| e.to_string())?;
    let total_revenue: f64 = conn
        .query_row("SELECT COALESCE(SUM(paid_amount),0) FROM invoices", [], |r| r.get(0))
        .map_err(|e| e.to_string())?;
    let pending_invoices: i64 = conn
        .query_row("SELECT COUNT(*) FROM invoices WHERE status != 'paid'", [], |r| r.get(0))
        .map_err(|e| e.to_string())?;

    let mut rev_stmt = conn
        .prepare(
            "SELECT strftime('%Y-%m', paid_at) as m, SUM(amount) FROM payments GROUP BY m ORDER BY m DESC LIMIT 6",
        )
        .map_err(|e| e.to_string())?;
    let revenue_by_month: Vec<MonthlyRevenue> = rev_stmt
        .query_map([], |r| {
            Ok(MonthlyRevenue { month: r.get(0)?, total: r.get(1)? })
        })
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;

    let mut act_stmt = conn
        .prepare("SELECT id, kind, message, created_at FROM activity_log ORDER BY created_at DESC LIMIT 10")
        .map_err(|e| e.to_string())?;
    let recent_activity: Vec<ActivityEntry> = act_stmt
        .query_map([], |r| {
            Ok(ActivityEntry { id: r.get(0)?, kind: r.get(1)?, message: r.get(2)?, created_at: r.get(3)? })
        })
        .map_err(|e| e.to_string())?
        .collect::<Result<Vec<_>, _>>()
        .map_err(|e| e.to_string())?;

    Ok(DashboardStats {
        total_clients, total_projects, active_projects, delayed_projects,
        completed_projects, total_revenue, pending_invoices, revenue_by_month, recent_activity,
    })
}

// ───────────────────────── Settings ─────────────────────────

#[tauri::command]
pub fn get_setting(state: State<DbState>, key: String) -> Result<Option<String>, String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.query_row("SELECT value FROM settings WHERE key=?1", params![key], |r| r.get(0))
        .map_err(|e| e.to_string())
        .or(Ok(None))
}

#[tauri::command]
pub fn set_setting(state: State<DbState>, key: String, value: String) -> Result<(), String> {
    let conn = state.0.lock().map_err(|e| e.to_string())?;
    conn.execute(
        "INSERT INTO settings (key, value) VALUES (?1, ?2)
         ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        params![key, value],
    )
    .map_err(|e| e.to_string())?;
    Ok(())
}

// ───────────────────────── Backups ─────────────────────────

#[tauri::command]
pub fn run_backup() -> Result<String, String> {
    crate::db::backup_database()
        .map(|p| p.to_string_lossy().to_string())
        .map_err(|e| e.to_string())
}
