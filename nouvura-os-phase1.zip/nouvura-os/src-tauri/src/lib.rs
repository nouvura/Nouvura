mod commands;
mod db;
mod models;

use db::DbState;
use std::sync::Mutex;

#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    let connection = db::init_connection().expect("failed to initialize NOUVURA OS database");

    tauri::Builder::default()
        .manage(DbState(Mutex::new(connection)))
        .invoke_handler(tauri::generate_handler![
            commands::list_clients,
            commands::create_client,
            commands::update_client,
            commands::delete_client,
            commands::get_dashboard_stats,
            commands::get_setting,
            commands::set_setting,
            commands::run_backup,
        ])
        .run(tauri::generate_context!())
        .expect("error while running NOUVURA OS");
}
