use serde::{Deserialize, Serialize};

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Client {
    pub id: String,
    pub name: String,
    pub company: Option<String>,
    pub phone: Option<String>,
    pub email: Option<String>,
    pub address: Option<String>,
    pub notes: Option<String>,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Deserialize)]
pub struct NewClient {
    pub name: String,
    pub company: Option<String>,
    pub phone: Option<String>,
    pub email: Option<String>,
    pub address: Option<String>,
    pub notes: Option<String>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct Project {
    pub id: String,
    pub code: String,
    pub client_id: String,
    pub title: String,
    pub status: String, // new | in_progress | waiting_client | completed | archived
    pub priority: String, // low | medium | high
    pub deadline: Option<String>,
    pub budget: Option<f64>,
    pub progress: i64, // 0-100
    pub notes: Option<String>,
    pub created_at: String,
    pub updated_at: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct DashboardStats {
    pub total_clients: i64,
    pub total_projects: i64,
    pub active_projects: i64,
    pub delayed_projects: i64,
    pub completed_projects: i64,
    pub total_revenue: f64,
    pub pending_invoices: i64,
    pub revenue_by_month: Vec<MonthlyRevenue>,
    pub recent_activity: Vec<ActivityEntry>,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct MonthlyRevenue {
    pub month: String,
    pub total: f64,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct ActivityEntry {
    pub id: String,
    pub kind: String,
    pub message: String,
    pub created_at: String,
}

#[derive(Debug, Serialize, Deserialize, Clone)]
pub struct AppSetting {
    pub key: String,
    pub value: String,
}
