import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import fr from "./locales/fr.json";
import en from "./locales/en.json";
import ar from "./locales/ar.json";

export const SUPPORTED_LANGUAGES = ["fr", "en", "ar"] as const;
export type SupportedLanguage = (typeof SUPPORTED_LANGUAGES)[number];

const STORAGE_KEY = "nouvura-os-language";

// Language persists locally (no cloud sync, per the offline-first requirement)
// and is also mirrored into the SQLite settings table by the Settings module
// so it survives a full reinstall of the frontend assets.
export function getStoredLanguage(): SupportedLanguage {
  const stored = window.localStorage?.getItem(STORAGE_KEY);
  if (stored && (SUPPORTED_LANGUAGES as readonly string[]).includes(stored)) {
    return stored as SupportedLanguage;
  }
  return "fr"; // French is the mandated default on first launch
}

export function applyDirection(lang: SupportedLanguage) {
  document.documentElement.lang = lang;
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
}

export function setLanguage(lang: SupportedLanguage) {
  window.localStorage?.setItem(STORAGE_KEY, lang);
  applyDirection(lang);
  i18n.changeLanguage(lang);
}

i18n.use(initReactI18next).init({
  resources: {
    fr: { translation: fr },
    en: { translation: en },
    ar: { translation: ar },
  },
  lng: getStoredLanguage(),
  fallbackLng: "fr",
  interpolation: { escapeValue: false },
});

applyDirection(getStoredLanguage());

export default i18n;
