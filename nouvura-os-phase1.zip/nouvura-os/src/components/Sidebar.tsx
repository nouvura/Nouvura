import { NavLink } from "react-router-dom";
import { useTranslation } from "react-i18next";
import {
  LayoutDashboard,
  Users,
  FolderKanban,
  FileText,
  Receipt,
  Calendar,
  FolderOpen,
  BarChart3,
  Archive,
  Settings,
  ChevronsLeft,
  ChevronsRight,
} from "lucide-react";
import { useAppStore } from "@/store/useAppStore";

const NAV_ITEMS = [
  { to: "/", icon: LayoutDashboard, key: "dashboard" },
  { to: "/clients", icon: Users, key: "clients" },
  { to: "/projects", icon: FolderKanban, key: "projects" },
  { to: "/quotes", icon: FileText, key: "quotes" },
  { to: "/invoices", icon: Receipt, key: "invoices" },
  { to: "/calendar", icon: Calendar, key: "calendar" },
  { to: "/files", icon: FolderOpen, key: "files" },
  { to: "/reports", icon: BarChart3, key: "reports" },
  { to: "/archive", icon: Archive, key: "archive" },
  { to: "/settings", icon: Settings, key: "settings" },
] as const;

export default function Sidebar() {
  const { t } = useTranslation();
  const { sidebarCollapsed, toggleSidebar } = useAppStore();

  return (
    <aside
      className="nv-panel flex flex-col shrink-0 h-full transition-[width] duration-300"
      style={{ width: sidebarCollapsed ? "var(--sidebar-w-collapsed)" : "var(--sidebar-w)" }}
    >
      <div className="flex items-center gap-3 px-4 h-16 border-b border-line">
        <div
          className="w-8 h-8 rounded-md flex items-center justify-center shrink-0"
          style={{
            background: "linear-gradient(135deg, rgba(0,240,255,0.18), rgba(0,240,255,0.06))",
            border: "1px solid rgba(0,240,255,0.35)",
            boxShadow: "0 0 16px rgba(0,240,255,0.2)",
          }}
        >
          <span className="font-display text-cyan text-sm font-bold">N</span>
        </div>
        {!sidebarCollapsed && (
          <span className="nv-label nv-glow-text text-cyan text-sm">NOUVURA OS</span>
        )}
      </div>

      <nav className="flex-1 overflow-y-auto py-3 px-2 space-y-1">
        {NAV_ITEMS.map(({ to, icon: Icon, key }) => (
          <NavLink
            key={key}
            to={to}
            end={to === "/"}
            className={({ isActive }) =>
              [
                "flex items-center gap-3 px-3 py-2.5 rounded-md transition-all duration-200 group relative",
                isActive
                  ? "bg-[rgba(0,240,255,0.1)] text-cyan shadow-glow"
                  : "text-ink-dim hover:text-cyan hover:bg-[rgba(0,240,255,0.05)]",
              ].join(" ")
            }
          >
            <Icon size={18} className="shrink-0" />
            {!sidebarCollapsed && (
              <span className="font-body text-sm tracking-wide truncate">{t(`nav.${key}`)}</span>
            )}
          </NavLink>
        ))}
      </nav>

      <button
        onClick={toggleSidebar}
        className="flex items-center justify-center gap-2 h-12 border-t border-line text-ink-dim hover:text-cyan transition-colors"
        aria-label={sidebarCollapsed ? "Expand sidebar" : "Collapse sidebar"}
      >
        {sidebarCollapsed ? <ChevronsRight size={16} /> : <ChevronsLeft size={16} />}
      </button>
    </aside>
  );
}
