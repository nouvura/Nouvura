import { useTranslation } from "react-i18next";
import { Search, Bell, Plus } from "lucide-react";
import { useAppStore } from "@/store/useAppStore";
import type { SupportedLanguage } from "@/i18n";

const LANGS: { code: SupportedLanguage; label: string }[] = [
  { code: "fr", label: "FR" },
  { code: "en", label: "EN" },
  { code: "ar", label: "AR" },
];

export default function Topbar() {
  const { t } = useTranslation();
  const { language, changeLanguage } = useAppStore();

  return (
    <header
      className="nv-panel flex items-center gap-4 px-5 shrink-0"
      style={{ height: "var(--topbar-h)" }}
    >
      <div className="flex items-center max-w-md flex-1 gap-2 nv-input">
        <Search size={16} className="text-ink-dim shrink-0" />
        <input
          className="bg-transparent outline-none text-sm flex-1 placeholder:text-ink-dim"
          placeholder={t("topbar.search") ?? undefined}
        />
      </div>

      <div className="flex-1" />

      <button className="nv-btn flex items-center gap-2">
        <Plus size={14} />
        {t("topbar.newProject")}
      </button>

      <button className="relative text-ink-dim hover:text-cyan transition-colors" aria-label="Notifications">
        <Bell size={18} />
      </button>

      <div className="flex items-center gap-1 nv-panel !border-line px-1 py-1 rounded-md" role="group" aria-label="Language">
        {LANGS.map(({ code, label }) => (
          <button
            key={code}
            onClick={() => changeLanguage(code)}
            className={[
              "nv-label text-[10px] px-2.5 py-1.5 rounded transition-all",
              language === code
                ? "text-cyan bg-[rgba(0,240,255,0.1)] shadow-glow"
                : "text-ink-dim hover:text-cyan",
            ].join(" ")}
          >
            {label}
          </button>
        ))}
      </div>
    </header>
  );
}
