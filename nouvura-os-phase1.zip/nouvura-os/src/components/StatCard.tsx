import type { LucideIcon } from "lucide-react";

interface StatCardProps {
  label: string;
  value: string | number;
  icon: LucideIcon;
  accent?: "cyan" | "amber" | "violet" | "red";
}

const ACCENT_MAP: Record<NonNullable<StatCardProps["accent"]>, string> = {
  cyan: "rgba(0,240,255,0.9)",
  amber: "#ffb800",
  violet: "#a78bfa",
  red: "#ff3b5c",
};

export default function StatCard({ label, value, icon: Icon, accent = "cyan" }: StatCardProps) {
  const color = ACCENT_MAP[accent];
  return (
    <div className="nv-panel p-5 flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <span className="nv-label text-[10px] text-ink-dim">{label}</span>
        <Icon size={18} style={{ color }} />
      </div>
      <span
        className="font-display text-2xl font-bold"
        style={{ color, textShadow: `0 0 18px ${color}55` }}
      >
        {value}
      </span>
    </div>
  );
}
