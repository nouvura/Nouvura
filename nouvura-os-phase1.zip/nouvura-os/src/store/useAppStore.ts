import { create } from "zustand";
import type { SupportedLanguage } from "@/i18n";
import { getStoredLanguage, setLanguage as persistLanguage } from "@/i18n";

interface AppState {
  sidebarCollapsed: boolean;
  toggleSidebar: () => void;
  language: SupportedLanguage;
  changeLanguage: (lang: SupportedLanguage) => void;
}

export const useAppStore = create<AppState>((set) => ({
  sidebarCollapsed: false,
  toggleSidebar: () => set((s) => ({ sidebarCollapsed: !s.sidebarCollapsed })),
  language: getStoredLanguage(),
  changeLanguage: (lang) => {
    persistLanguage(lang);
    set({ language: lang });
  },
}));
