import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Plus, Pencil, Trash2, X } from "lucide-react";
import { db } from "@/lib/db";
import type { Client, NewClient } from "@/types";

const EMPTY_FORM: NewClient = {
  name: "",
  company: null,
  phone: null,
  email: null,
  address: null,
  notes: null,
};

export default function Clients() {
  const { t } = useTranslation();
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [form, setForm] = useState<NewClient>(EMPTY_FORM);

  const load = () => {
    setLoading(true);
    db.listClients()
      .then(setClients)
      .finally(() => setLoading(false));
  };

  useEffect(load, []);

  const openCreate = () => {
    setEditingId(null);
    setForm(EMPTY_FORM);
    setModalOpen(true);
  };

  const openEdit = (client: Client) => {
    setEditingId(client.id);
    setForm({
      name: client.name,
      company: client.company,
      phone: client.phone,
      email: client.email,
      address: client.address,
      notes: client.notes,
    });
    setModalOpen(true);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.name.trim()) return;
    if (editingId) {
      await db.updateClient(editingId, form);
    } else {
      await db.createClient(form);
    }
    setModalOpen(false);
    load();
  };

  const handleDelete = async (id: string) => {
    if (!window.confirm(t("clients.confirmDelete") ?? "")) return;
    await db.deleteClient(id);
    load();
  };

  return (
    <div className="flex flex-col gap-6">
      <div className="flex items-start justify-between">
        <div>
          <h1 className="font-display text-xl font-bold text-cyan nv-glow-text tracking-wide">
            {t("clients.title")}
          </h1>
          <p className="text-ink-dim text-sm mt-1">{t("clients.subtitle")}</p>
        </div>
        <button onClick={openCreate} className="nv-btn flex items-center gap-2">
          <Plus size={14} />
          {t("clients.newClient")}
        </button>
      </div>

      {loading ? (
        <p className="text-ink-dim font-body">{t("common.loading")}</p>
      ) : clients.length === 0 ? (
        <div className="nv-panel p-10 text-center text-ink-dim text-sm">{t("clients.empty")}</div>
      ) : (
        <div className="nv-panel overflow-hidden">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-line text-left">
                <th className="nv-label text-[10px] text-ink-dim font-medium px-4 py-3">{t("clients.name")}</th>
                <th className="nv-label text-[10px] text-ink-dim font-medium px-4 py-3">{t("clients.company")}</th>
                <th className="nv-label text-[10px] text-ink-dim font-medium px-4 py-3">{t("clients.phone")}</th>
                <th className="nv-label text-[10px] text-ink-dim font-medium px-4 py-3">{t("clients.email")}</th>
                <th className="px-4 py-3" />
              </tr>
            </thead>
            <tbody>
              {clients.map((c) => (
                <tr key={c.id} className="border-b border-line/50 last:border-0 hover:bg-[rgba(0,240,255,0.03)]">
                  <td className="px-4 py-3 font-medium">{c.name}</td>
                  <td className="px-4 py-3 text-ink-dim">{c.company || "—"}</td>
                  <td className="px-4 py-3 text-ink-dim">{c.phone || "—"}</td>
                  <td className="px-4 py-3 text-ink-dim">{c.email || "—"}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center gap-3 justify-end">
                      <button onClick={() => openEdit(c)} className="text-ink-dim hover:text-cyan transition-colors" aria-label={t("clients.edit") ?? undefined}>
                        <Pencil size={15} />
                      </button>
                      <button onClick={() => handleDelete(c.id)} className="text-ink-dim hover:text-status-overdue transition-colors" aria-label={t("clients.delete") ?? undefined}>
                        <Trash2 size={15} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {modalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="nv-panel w-full max-w-md p-6 relative">
            <button
              onClick={() => setModalOpen(false)}
              className="absolute top-4 right-4 text-ink-dim hover:text-cyan"
              aria-label={t("clients.cancel") ?? undefined}
            >
              <X size={18} />
            </button>
            <h2 className="font-display text-cyan text-sm tracking-wide mb-5">
              {editingId ? t("clients.edit") : t("clients.newClient")}
            </h2>
            <form onSubmit={handleSubmit} className="flex flex-col gap-3">
              <input
                className="nv-input"
                placeholder={t("clients.name") ?? undefined}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                required
              />
              <input
                className="nv-input"
                placeholder={t("clients.company") ?? undefined}
                value={form.company ?? ""}
                onChange={(e) => setForm({ ...form, company: e.target.value || null })}
              />
              <input
                className="nv-input"
                placeholder={t("clients.phone") ?? undefined}
                value={form.phone ?? ""}
                onChange={(e) => setForm({ ...form, phone: e.target.value || null })}
              />
              <input
                className="nv-input"
                type="email"
                placeholder={t("clients.email") ?? undefined}
                value={form.email ?? ""}
                onChange={(e) => setForm({ ...form, email: e.target.value || null })}
              />
              <input
                className="nv-input"
                placeholder={t("clients.address") ?? undefined}
                value={form.address ?? ""}
                onChange={(e) => setForm({ ...form, address: e.target.value || null })}
              />
              <textarea
                className="nv-input resize-none"
                rows={3}
                placeholder={t("clients.notes") ?? undefined}
                value={form.notes ?? ""}
                onChange={(e) => setForm({ ...form, notes: e.target.value || null })}
              />
              <div className="flex justify-end gap-3 mt-2">
                <button type="button" onClick={() => setModalOpen(false)} className="nv-btn-ghost">
                  {t("clients.cancel")}
                </button>
                <button type="submit" className="nv-btn">
                  {t("clients.save")}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
