/**
 * Placeholder — built in the next phase, following the exact same
 * pattern as Clients.tsx (Rust command -> lib/db.ts -> typed page).
 */
export default function Invoices() {
  return (
    <div className="flex flex-col items-center justify-center h-full text-center gap-3">
      <span className="nv-label text-cyan text-sm">Invoices</span>
      <p className="text-ink-dim text-sm max-w-sm">
        This module ships in the next build phase. Navigation, layout, and
        language switching above are already fully wired.
      </p>
    </div>
  );
}
