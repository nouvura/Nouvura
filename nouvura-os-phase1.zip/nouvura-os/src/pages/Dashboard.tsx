import { useEffect, useState } from "react";
import { useTranslation } from "react-i18next";
import { Users, FolderKanban, AlertTriangle, CheckCircle2 } from "lucide-react";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import StatCard from "@/components/StatCard";
import { db } from "@/lib/db";
import type { DashboardStats } from "@/types";

export default function Dashboard() {
  const { t } = useTranslation();
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    db.getDashboardStats()
      .then(setStats)
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return <p className="text-ink-dim font-body">{t("common.loading")}</p>;
  }
  if (!stats) {
    return <p className="text-status-overdue font-body">{t("common.error")}</p>;
  }

  const chartData = [...stats.revenue_by_month].reverse();

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="font-display text-xl font-bold text-cyan nv-glow-text tracking-wide">
          {t("dashboard.title")}
        </h1>
        <p className="text-ink-dim text-sm mt-1">{t("dashboard.subtitle")}</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <StatCard label={t("dashboard.totalClients")} value={stats.total_clients} icon={Users} accent="cyan" />
        <StatCard label={t("dashboard.activeProjects")} value={stats.active_projects} icon={FolderKanban} accent="violet" />
        <StatCard label={t("dashboard.delayedProjects")} value={stats.delayed_projects} icon={AlertTriangle} accent="red" />
        <StatCard label={t("dashboard.completedProjects")} value={stats.completed_projects} icon={CheckCircle2} accent="amber" />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="nv-panel p-5 lg:col-span-2">
          <h2 className="nv-label text-xs text-ink-dim mb-4">{t("dashboard.revenueChart")}</h2>
          <ResponsiveContainer width="100%" height={240}>
            <LineChart data={chartData}>
              <CartesianGrid stroke="rgba(0,240,255,0.08)" vertical={false} />
              <XAxis dataKey="month" stroke="rgba(255,235,240,0.4)" fontSize={11} />
              <YAxis stroke="rgba(255,235,240,0.4)" fontSize={11} />
              <Tooltip
                contentStyle={{
                  background: "#170209",
                  border: "1px solid rgba(0,240,255,0.3)",
                  borderRadius: 6,
                  color: "#fff",
                }}
              />
              <Line type="monotone" dataKey="total" stroke="#00f0ff" strokeWidth={2} dot={{ r: 3 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>

        <div className="nv-panel p-5">
          <h2 className="nv-label text-xs text-ink-dim mb-4">{t("dashboard.recentActivity")}</h2>
          {stats.recent_activity.length === 0 ? (
            <p className="text-ink-dim text-sm">{t("dashboard.noActivity")}</p>
          ) : (
            <ul className="space-y-3">
              {stats.recent_activity.map((entry) => (
                <li key={entry.id} className="flex gap-3 text-sm">
                  <span className="w-1.5 h-1.5 rounded-full bg-cyan mt-1.5 shrink-0 shadow-glow" />
                  <span className="text-ink-dim">{entry.message}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}
