import { HashRouter, Routes, Route } from "react-router-dom";
import AppShell from "@/layouts/AppShell";
import Dashboard from "@/pages/Dashboard";
import Clients from "@/pages/Clients";
import Projects from "@/pages/Projects";
import Quotes from "@/pages/Quotes";
import Invoices from "@/pages/Invoices";
import CalendarPage from "@/pages/CalendarPage";
import Files from "@/pages/Files";
import Reports from "@/pages/Reports";
import ArchivePage from "@/pages/ArchivePage";
import Settings from "@/pages/Settings";

// HashRouter (not BrowserRouter) is required here: a Tauri window loads
// the frontend from a local file/asset origin with no server doing
// history-mode fallback routing, so hash-based routes are the reliable
// choice for a desktop build.
export default function App() {
  return (
    <HashRouter>
      <Routes>
        <Route element={<AppShell />}>
          <Route index element={<Dashboard />} />
          <Route path="clients" element={<Clients />} />
          <Route path="projects" element={<Projects />} />
          <Route path="quotes" element={<Quotes />} />
          <Route path="invoices" element={<Invoices />} />
          <Route path="calendar" element={<CalendarPage />} />
          <Route path="files" element={<Files />} />
          <Route path="reports" element={<Reports />} />
          <Route path="archive" element={<ArchivePage />} />
          <Route path="settings" element={<Settings />} />
        </Route>
      </Routes>
    </HashRouter>
  );
}
