import type { Client, DashboardStats, NewClient } from "@/types";

// NOUVURA OS talks to its SQLite database exclusively through Tauri's
// `invoke` bridge — there is no HTTP layer and no network call anywhere
// in this file, by design (offline-first requirement).
//
// Running `npm run dev` in a plain browser (outside `tauri dev`) is still
// useful for fast UI iteration, so when `window.__TAURI__` isn't present
// we transparently fall back to an in-memory mock store instead of
// crashing. Anything built with `npm run tauri build` always uses the
// real Rust/SQLite backend.

const isTauri = () => typeof window !== "undefined" && "__TAURI__" in window;

async function invoke<T>(cmd: string, args?: Record<string, unknown>): Promise<T> {
  const { invoke: tauriInvoke } = await import("@tauri-apps/api/core");
  return tauriInvoke<T>(cmd, args);
}

// ───────────────────────── Mock data (browser preview only) ─────────────────────────

let mockClients: Client[] = [
  {
    id: "mock-1",
    name: "Yacine Iguenene",
    company: "Bergerie Ajennad",
    phone: "+213 776 53 20 42",
    email: "contact@ajennad.dz",
    address: "Tizi Ouzou",
    notes: "Client fondateur — refonte site en cours.",
    created_at: new Date().toISOString(),
    updated_at: new Date().toISOString(),
  },
];

const mockStats: DashboardStats = {
  total_clients: 1,
  total_projects: 3,
  active_projects: 2,
  delayed_projects: 1,
  completed_projects: 1,
  total_revenue: 245000,
  pending_invoices: 2,
  revenue_by_month: [
    { month: "2026-01", total: 60000 },
    { month: "2026-02", total: 45000 },
    { month: "2026-03", total: 80000 },
    { month: "2026-04", total: 30000 },
    { month: "2026-05", total: 90000 },
    { month: "2026-06", total: 70000 },
  ],
  recent_activity: [
    { id: "a1", kind: "client_created", message: "Nouveau client : Bergerie Ajennad", created_at: new Date().toISOString() },
  ],
};

// ───────────────────────── Public API ─────────────────────────

export const db = {
  async listClients(): Promise<Client[]> {
    if (!isTauri()) return mockClients;
    return invoke<Client[]>("list_clients");
  },

  async createClient(payload: NewClient): Promise<Client> {
    if (!isTauri()) {
      const client: Client = {
        ...payload,
        id: crypto.randomUUID(),
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString(),
      };
      mockClients = [client, ...mockClients];
      return client;
    }
    return invoke<Client>("create_client", { payload });
  },

  async updateClient(id: string, payload: NewClient): Promise<void> {
    if (!isTauri()) {
      mockClients = mockClients.map((c) => (c.id === id ? { ...c, ...payload } : c));
      return;
    }
    return invoke<void>("update_client", { id, payload });
  },

  async deleteClient(id: string): Promise<void> {
    if (!isTauri()) {
      mockClients = mockClients.filter((c) => c.id !== id);
      return;
    }
    return invoke<void>("delete_client", { id });
  },

  async getDashboardStats(): Promise<DashboardStats> {
    if (!isTauri()) return mockStats;
    return invoke<DashboardStats>("get_dashboard_stats");
  },

  async getSetting(key: string): Promise<string | null> {
    if (!isTauri()) return null;
    return invoke<string | null>("get_setting", { key });
  },

  async setSetting(key: string, value: string): Promise<void> {
    if (!isTauri()) return;
    return invoke<void>("set_setting", { key, value });
  },

  async runBackup(): Promise<string> {
    if (!isTauri()) throw new Error("Backups require the desktop app (not available in browser preview).");
    return invoke<string>("run_backup");
  },
};
