import { Outlet } from "react-router-dom";
import Sidebar from "@/components/Sidebar";
import Topbar from "@/components/Topbar";

export default function AppShell() {
  return (
    <div className="flex h-screen w-screen p-3 gap-3">
      <Sidebar />
      <div className="flex flex-col flex-1 gap-3 min-w-0">
        <Topbar />
        <main className="flex-1 overflow-y-auto nv-panel p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
