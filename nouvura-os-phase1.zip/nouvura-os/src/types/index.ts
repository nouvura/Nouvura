export interface Client {
  id: string;
  name: string;
  company: string | null;
  phone: string | null;
  email: string | null;
  address: string | null;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export type NewClient = Omit<Client, "id" | "created_at" | "updated_at">;

export type ProjectStatus =
  | "new"
  | "in_progress"
  | "waiting_client"
  | "completed"
  | "archived";

export interface Project {
  id: string;
  code: string;
  client_id: string;
  title: string;
  status: ProjectStatus;
  priority: "low" | "medium" | "high";
  deadline: string | null;
  budget: number | null;
  progress: number;
  notes: string | null;
  created_at: string;
  updated_at: string;
}

export interface MonthlyRevenue {
  month: string;
  total: number;
}

export interface ActivityEntry {
  id: string;
  kind: string;
  message: string;
  created_at: string;
}

export interface DashboardStats {
  total_clients: number;
  total_projects: number;
  active_projects: number;
  delayed_projects: number;
  completed_projects: number;
  total_revenue: number;
  pending_invoices: number;
  revenue_by_month: MonthlyRevenue[];
  recent_activity: ActivityEntry[];
}
